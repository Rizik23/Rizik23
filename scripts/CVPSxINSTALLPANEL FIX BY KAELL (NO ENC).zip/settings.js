require("./system/module.js")

//==============================================//
global.owner = "-"
global.namabot = "CVPS" 
global.versi = "1.0.0"
global.negara = "INDONESIA 🇮🇩"
global.namaOwner = "-"
global.namaowner = "-"
global.packname = "-"
global.author = "-"
global.botname = "CVPS"
global.botname2 = "CVPS"
global.thumbbot = "https://files.catbox.moe/0jflc9.jpg"
global.urlfoto = 'https://files.catbox.moe/0jflc9.jpg'

global.image = {
digitalocean: "https://img12.pixhost.to/images/900/575791755_sano.jpg",
reply: "https://files.catbox.moe/0jflc9.jpg", 
menu: "https://files.catbox.moe/0jflc9.jpg",    
};
//==============================================//
global.linksaluran = "-"
global.linkweb = "-"

global.idsaluran = "-@newsletter"
global.namasaluran = "-"
global.channel = "-"
global.linkgrub = "",

global.tokeninstall = "kepojir"
global.bash = "bash <(curl https://raw.githubusercontent.com/RafatharUserbotV4/Rafaxamalia/main/install.sh)"

global.apiDigitalOcean = {
akun1:
"dop_v1_88ddc1cf8aeb065b99c061ea4e11899b86f9cfaaff65414a4b3638d43f592b1e",
    akun2: "",
    akun3: "",
    akun4: "",
    akun5: "",
    akun6: "",
    akun7: "",
    akun8: "",
    akun9: "",
    akun10: "",
    akun11: "",
    akun12: "",
    akun13: "-",
    akun14: "-",
    akun15: "-",
    akun16: "-",
    akun17: "-",
    akun18: "-",
    akun19: "-",
    akun20: "-",
    akun21: "-",
    akun22: "-",
    akun23: "-",
    akun24: "-",
    akun25: "-",
    akun26: "-",
    akun27: "-",
    akun28: "-",
    akun29: "-",
    akun30: "-",
    akun31: "-",
    akun32: "-",
    akun33: "-",
    akun34: "—",
    akun35: "—",
    akun36: "—",
    akun37: "—",
    akun38: "—",
    akun39: "—",
    akun40: "—",
    akun41: "—",
    akun42: "—",
    akun43: "—",
    akun44: "—",
    akun45: "—",
    akun46: "—",
    akun47: "—",
    akun48: "—",
    akun49: "—",
    akun50: "—"
}

global.subdomain = {
    "storexyz.web.id": {
        zone: "6c8e7372366812fb4404f471ce6e8566", 
        apitoken: "6eUI9W-hbohuMBRaIJ3hIy76ceAV25kgRddGN-LH"
    }, 
    "ymzprivat.biz.id": {
        zone: "224d4a27f97d5895c8df248bd8d083bf", 
        apitoken: "LhEpIRt1GG_CYUCGGxeQ7AkOELqy530vERBuvIN2"
    },
    "ymzpterodactyl.biz.id": {
        zone: "c259026028b5a0a5cad9a4624a677f36", 
        apitoken: "iiRn_WvgI8inVMF2hJdDO06OvniBx9Hu1KF0IUJu"
    }, 
    "xyzraa.biz.id": {
        zone: "9fafb2671fa1a4f67a2044803e283780",
        apitoken: "q54b8QI-LXyXkyGIW0W9MbcIsB6t558087L9to-Q"
    },
    "veyoradev.biz.id": {
        zone: "c03458c7996fa426258cb75be6d23716", 
        apitoken: "Lq9GCBQ6c5J1YuRm6DfymLuBUpXJJO1YN1zQlwJQ"
    }, 
    "kinzprivat.biz.id": {
        zone: "cfbff196cdd671efd6fcd2d8662f1028",
        apitoken: "fmb9lwRjiEi_F5wPaEE3Ior5FgEA69SwyqvoupSj"
    },
    "publicman.biz.id": {
        zone: "03e13f30207530bf23708d4a1f965262", 
        apitoken: "Xz0tV1WF2za6YLc0luAbXcKUrj47jFia9ge5dKZx"
    },
    "privatboy.biz.id": {
        zone: "ba5962ef94baa7b8797c1e4813517d2d", 
        apitoken: "5V2poakbDvpTk-I_CNhJw4CzJK72kJWUi_lqyy6a"
    },
    "myserverr.web.id": {
        zone: "2ebdbbf3d1edf834395d9596dd0e0d53",
        apitoken: "Yh87xMgv4zhQNOYZ49kBiVkM7Lf9DKmmm_xCrKP5"
    },
    "zonapanel.web.id": {
        zone: "b9acd64d7e7fa4cd2007139a8f2d4779",
        apitoken: "G-Quh__J5ZpFi6NQSxbsySDVRko4gnZ3EhsvbNtX"
    },
    "privatesrvr.xyz": {
        zone: "b488e5d4635431243cab94d5fec4a3d2",
        apitoken: "Wv6SqCo8772I6WG-EGnD4w272sJsYVSXd-LpPc7C"
    },
    "cfxcloud.com": {
        zone: "fbcecbe90d0c2c2cfcd3f8ca7b6c5998", 
        apitoken: "KUbEHB0u1LlAyto_WdIwzTE6PUF5SF7JAxi13fpL"
    }, 
    "cloudxyz.web.id": {
        zone: "29ab1a42ba3519ad5774d5ad5f780091",
        apitoken: "sLKBjuhW9iUQiDyd8a_2HvG5YzxMLPda1vdCbGQX"
    },
    "hostingers-vvip.my.id": {
        zone: "2341ae01634b852230b7521af26c261f", 
        apitoken: "Ztw1ouD8_lJf-QzRecgmijjsDJODFU4b-y697lPw"
    },
    "ekiofficial.my.id": {
        zone: "df33365b44b11cbe51570a7ed981cae5", 
        apitoken: "rMJGbyeuwFVZJifsB3rIX-nRpIOOa4Wkrhu7V5Jo"
    },
    "ekiofficial.web.id": {
        zone: "e1b037c00268cae95076b58f7f78b1f6", 
        apitoken: "EJO7mHrBORH9XoQrnUvBqotMYxNm5bjB5UO2PeQE"
    },
    "eki-panelpvrt.my.id": {
        zone: "6b4cb792b77b6118e91d8604253ca572", 
        apitoken: "DsftwwFCAKrbSo-9r9hxqcscMw8Xvx8gQzTXMSz4"
    },
    "googlehost.biz.id": {
        zone: "aab7652200b19a2d3309f4fc09b60d09",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "googlex.my.id": {
        zone: "dda9e25dac2556c7494470ee6152fc7f",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "heavencraft.my.id": {
        zone: "9e7239dcda7cbd6be79d7615257f56f8", 
        apitoken: "aHvYYKk7YIADVOfpG3i1eaIqTeWCdPS25FAPreDQ"
    },
    "hilman-store.web.id": {
        zone: "4e214dfe36faa7c942bc68b5aecdd1e9",
        apitoken: "wpQCANKLRAtWb0XvTRed3vwSkOMMWKO2C75uwnKE"
    },
    "hilmanofficial.tech": {
        zone: "c8705bfbfdca9c4e8e61eb2663ee87d6",
        apitoken: "hjqWa_eFAfoJNJyBu9WAlg8WO0ICtN5AYpZURgqe"
    },
    "hilmanzoffc.web.id": {
        zone: "2627badfda28951bfb936fce0febc5b0",
        apitoken: "wZ3QAKn7zDx-tyb04HgCvmogqeM6je8jDNmiPZXq"
    },
    "host-panel.web.id": {
        zone: "74b3192f7c3b0925cdb8606bb7db95c4",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostingers-vvip.my.id": {
        zone: "2341ae01634b852230b7521af26c261f",
        apitoken: "Ztw1ouD8_lJf-QzRecgmijjsDJODFU4b-y697lPw"
    },
    "hostingnusantara.my.id": {
        zone: "156715abae5f34849a0f936753c986c8",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostpanel.biz.id": {
        zone: "76acbc398ab09c2bc0b179a7fa9ef488",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostsatoruu.biz.id": {
        zone: "30ea1aac05ca26dda61540e172f52ff4", 
        apitoken: "eZp1wNcc0Mj-btUQQ1cDIek2NZ6u1YW1Bxc2SB3z"
    },
    "jstpiwz.my.id": {
        zone: "f1901becfbd79f39048f7698de71d53b",
        apitoken: "g8_D70UKwk0hBeuPqdXgWmZcoNjwXMkfd3OEUL4k"
    },
    "jokowii.my.id": {
        zone: "67a887a21f43fea088a47902a436c400", 
        apitoken: "FwLKNhNL5LhI_LhAzH7pD-v6BrIcQ5dsdKRtaytS"
    },
    "kenz-host.my.id": {
        zone: "df24766ae8eeb04b330b71b5facde5f4",
        apitoken: "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
    },
    "lexcz.me": {
        zone: "7a4e7ca1131daf5a4c7ef03191432a6a",
        apitoken: "DTxnQFaoI9p2YtZUL7PLikauBvXcL_CWzpBbQx2b"
    },
    "lexczalok.xyz": {
        zone: "dd510b41fc4d7074c5be6f47f9f5b722",
        apitoken: "IsRLdOOP7OVrB95PUWaW_eq1n5T2T8OUcnwGhP_q"
    },
    "marketrikishop.my.id": {
        zone: "33970794e3373167a9c9556ad19fdb6a",
        apitoken: "TWf7dzMAu1dOc0XNuE98auJiSryxkUkQBbJpkwgr"
    },
    "pakvinsen.me": {
        zone: "3b8cb89265c0e026abaf3bc50ed57e76", 
        apitoken: "ttt0IHK50UKP2HltWUauuyDzkVPqnOEkx7M-5CFs"
    },
    "panelpro.fun": {
        zone: "a5c4697e86cf1cda49c0f81a699a690e",
        apitoken: "k-ZxmwqjyZf7iu4zNSJDTIx2tH6JZ--JQgfZReM9"
    },
    "panelpublic.biz.id": {
        zone: "92ed47fdfb94db589708b8057d44087f",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "prabowoo.my.id": {
        zone: "af679c959583e9eff1685ef4c7cbf048", 
        apitoken: "gGQeMyeo8jM5xNGMsfChkwrawZ3UiX3QUnBnvwTe"
    },
    "pterodactyl-panel.web.id": {
        zone: "d69feb7345d9e4dd5cfd7cce29e7d5b0",
        apitoken: "32zZwadzwc7qB4mzuDBJkk1xFyoQ2Grr27mAfJcB"
    },
    "pterodaytl.my.id": {
        zone: "828ef14600aaaa0b1ea881dd0e7972b2",
        apitoken: "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
    },
    "storedigital.web.id": {
        zone: "2ce8a2f880534806e2f463e3eec68d31",
        apitoken: "v5_unJTqruXV_x-5uj0dT5_Q4QAPThJbXzC2MmOQ"
    },
    "storeid.my.id": {
        zone: "c651c828a01962eb3c530513c7ad7dcf",
        apitoken: "N-D6fN6la7jY0AnvbWn9FcU6ZHuDitmFXd-JF04g"
    },
    "store-panell.my.id": {
        zone: "0189ecfadb9cf2c4a311c0a3ec8f0d5c", 
        apitoken: "eVI-BXIXNEQtBqLpdvuitAR5nXC2bLj6jw365JPZ"
    }, 
    "tamaoffc.biz.id": {
        zone: "177538af7fb12443a80892554d01206f",
        apitoken: "ZaVSjxa96NQDV6lQgspAVsVXrvVzdOpqL1z6PG0Z"
    },
    "tokopanelkishop.biz.id": {
        zone: "d87d4f320d9902f31fbbcc5ee23fafe8",
        apitoken: "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
    },
    "wannhosting.biz.id": {
        zone: "4e6fe33fb08c27d97389cad0246bfd9b",
        apitoken: "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
    },   
    "wannhosting.my.id": {
        zone: "0b36d11edd793b3f702e0591f0424339",
        apitoken: "OsSjhDZLdHImYTX8fdeiP1wocKwVnoPw5EiI85IF"
    }, 
    "webpanelku.my.id": {
        zone: "b41c3bb25273c4059b542c381250c9f9",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "xnxxx.tech": {
        zone: "639f9cde20c22b1d2f33b2fee54f8f59",
        apitoken: "MtWI3a9-9Za-fGKmwl0uNznqM94eljKgobkF36h1"
    },
    "xyro.me": {
        zone: "a1c08ecd2f96516f2a85250b98850e8b", 
        apitoken: "f3IBOeIjRHYSsRhzxBO7yiwl-Twn3fqjmdkLdwlf"
    }, 
    "xyro.web.id": {
        zone: "46d0cd33a7966f0be5afdab04b63e695", 
        apitoken: "CygwSHXRSfZnsi1qZmyB8s4qHC12jX_RR4mTpm62"
    }, 
    "xyroku.my.id": {
        zone: "f6d1a73a272e6e770a232c39979d5139", 
        apitoken: "0Mae_Rtx1ixGYenzFcNG9bbPd-rWjoRwqN2tvNzo"
    }, 
    "xpanelprivate.my.id": {
        zone: "f6bd04c23d4de3ec6d60d8eeabe1ff40", 
        apitoken: "su_zz3Amd5WkrOv95OA6uQb1Y6ky6qVtjkhQnPCi"
    },
    "zainhosting.my.id": {
        zone: "c3eeb2afb2e4073fe4c55ad7145395e9", 
        apitoken: "RNlg5vrTwt73uAPTYAad_nJzBmDhhjbUZKiWFORZ"
    },
    "zhirastoreid.me": {
        zone: "fc6c7f786d01a0c7558a313549134a06", 
        apitoken: "STOIGXwGftk-OjdgCbqpCDaBWCYUpo5RgvmJ-rXe"
    },
    "zyydev.my.id": {
        zone: "337aaf9a6689c7a7145480ef3ccaffdb",
        apitoken: "jnNO465SjNC-Ss6CDM2WDIy7jwzbKWHJuOXA5xak"
    }
}
//==============================================//
global.mess = {
wait: "Memproses . . .", 
prem: " [Akses ditolak]\n Fitur khusus wyii premium!",
owner: "Fitur ini khusus untuk owner wyiioffc!", 
group: "Fitur ini untuk dalam grup!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})