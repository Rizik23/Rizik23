**INI APK + API YAH BISA KALIAN DOWNLOAD**

## buat kalian yang ga bisa build jadi apk dan ga bisa pasang api, bisa jasa build ke contact aku yah chat aja telegram              https://t.me/Myzxa 

## untuk harga murmer yah list harga build ada di bawah
```
## Akses 1 hari Rp2.000 bisa custom hari di kali Rp2.000
## Akses 1 minggu Rp15.000
## Akses 1 bulan Rp20.000
## Akses Permanen - selamanya Rp25.000
```
## Untuk yang pertama buy apk + api di sarankan akses 1 hari dulu ( RECOMMENDED )

```
NAH INI APK NYA INI MASIH SCRIPT YAH JADI KALIAN HARUS BUILD JADI APK PAKE FLUTER BISA BUILD LEWAT VPS DI TERMUX, 
```
https://www.mediafire.com/file/xj57su5tl2dkyqx/RDVSP-VERSION-5.0.zip/file

```
NAH INI API NYA YAH VIA PANEL NODE 20+
```
https://www.mediafire.com/file/78sue2phkz3s7zd/API-RDVSP-VIA-PANEL.zip/file