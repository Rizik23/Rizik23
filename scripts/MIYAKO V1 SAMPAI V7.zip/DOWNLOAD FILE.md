## SILAHKAN DOWNLOAD FILE
```JIKA ADA KENDALA ATAU ERROR BISA CONTACT TELEGRAM
https://t.me/Myzxa
```
https://www.mediafire.com/file/po4xtfnpwbl0z77/MIYAKO+V1+SAMPAI+V7.zip/file