const settings = {
  // BOT SETTINGS
  token: '7637356981:AAG8Svu_uU-Qsn5_5XYUM34Yr5AoqkJoELU',
  ownerId: 7313120244,
  dev: 'dilzxxyz',
  
  // MEDIA
  panel: 'https://files.catbox.moe/w33rsl.jpg',
};

module.exports = settings;