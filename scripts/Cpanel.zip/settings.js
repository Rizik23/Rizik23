/* 

=======================================

SC CREATED BY : ©vina / ©vina
YT OWNER : https://youtube.com/@vinacantik36
TELE OWNER : @Vinacantik27
CONTACT : 08819909469

NOTE : Hargai Pengembang Dengan Cara Tidak Rename/Delete Credit Di Atas, Gunakan Semaumu Tapi Jangan Mengambil Karya Ku. Jika Ingin Merepost Kembali Tolong Tag Pengembang Dimanapun Itu Terima Kasih.

=======================================

*/
const settings = {
  owner: '8276237362', // ganti id telegram lu
  token: '8424944611:AAGn-rrbHB0jAezlckVJQ1bJB9W9KRGtyT0', // Token Bot Lu
  domain: 'https://dulxownpanel.storeid.my.id', // domain
  plta: 'ptla_M5TFrO0RB9yMS2VryQN0TzN5isQG5aLOKx1aJuu34mJ', // plta yang sesuai
  pltc: 'ptlc_6ysbUFv2hWrYT8QFj0bFHvFQpJhOGW77CBMMIXTqvkt', // pltc yang sesuai
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15',
};

module.exports = settings;