// config.js
//Credit Sarah-Xhin @CryCodexx - @XhinRb
module.exports = {
    BOT_TOKEN: "token", 
    ADMIN_ID: 7612475043  
};