const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const renlol = fs.readFileSync('./assets/images/thumb.jpeg');
const path = require("path");
const sessions = new Map();
const readline = require('readline');
const cd = "cooldown.json";
const axios = require("axios");
const chalk = require("chalk");
const config = require("./ботсет⨭/config.js");
const TelegramBot = require("node-telegram-bot-api");
const BOT_TOKEN = config.BOT_TOKEN;
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
/*
// Database check
const databaseURL = "https://raw.githubusercontent.com/keelXpowxzz/vyrosdatabase/refs/heads/main/token.json";

async function isTokenRegistered(token) {
    try {
        const response = await axios.get(databaseURL);
        const tokenData = response.data;

        if (!tokenData.tokens.includes(token)) {
            console.log("❌ Your Bot Token Is Not Registered\n- Please Contact The Owner\n- @keelextyy ( Telegram )");
            process.exit(1); // Keluar dari script
        } else {
            console.log("╭────⊱\n┃⊝─── Vyros Catalyst ✰\n┃–▢ Version : 5.0\n┃–▢ Developer : Keel OfficiaL\n┃–▢ WhatsApp : 6285134031285\n┃–▢ Telegram : @keelextyy\n┃\n┃Telegram Bot Successfully Connected\n╰──────────────⊱");
        }
    } catch (error) {
        console.error("❌ Gagal mengambil data token:", error.message);
        process.exit(1);
    }
}

// Panggil function sebelum menjalankan bot
isTokenRegistered(BOT_TOKEN);
*/
console.log(chalk.green.bold(`
╭────⊱
┃⊝─── Vyros Catalyst ✰
┃–▢ Version : 5.0
┃–▢ Developer : Keel OfficiaL
┃–▢ WhatsApp : 6285134031285
┃–▢ Telegram : @keelextyy
┃
┃✅ Telegram Bot Successfully Connected!
╰──────────────⊱
`));
// Pastikan file premium & admin ada
function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./ботсет⨭/premium.json');
ensureFileExists('./ботсет⨭/admin.json');

let premiumUsers = JSON.parse(fs.readFileSync('./ботсет⨭/premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./ботсет⨭/admin.json'));

function savePremiumUsers() {
    fs.writeFileSync('./ботсет⨭/premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./ботсет⨭/admin.json', JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./ботсет⨭/premium.json', (data) => (premiumUsers = data));
watchFile('./ботсет⨭/admin.json', (data) => (adminUsers = data));

// Nama file untuk menyimpan ID pengguna
const USER_IDS_FILE = './ботсет⨭/userids.json';

// Fungsi untuk membaca daftar ID pengguna dari file
function readUserIds() {
    try {
        const data = fs.readFileSync(USER_IDS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Gagal membaca daftar ID pengguna:', error);
        return [];
    }
}

// Fungsi untuk menyimpan daftar ID pengguna ke file
function saveUserIds(userIds) {
    try {
        fs.writeFileSync(USER_IDS_FILE, JSON.stringify(Array.from(userIds)), 'utf8');
    } catch (error) {
        console.error('Gagal menyimpan daftar ID pengguna:', error);
    }
}

// Set untuk menyimpan ID pengguna unik
const userIds = new Set(readUserIds());

// Fungsi untuk menambahkan ID pengguna baru
function addUser(userId) {
    if (!userIds.has(userId)) {
        userIds.add(userId);
        saveUserIds(userIds);
        console.log(`Pengguna ${userId} ditambahkan.`);
    }
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
/*
function startBot() {
  console.log(chalk.green.bold(`
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢛⣛⣛⠛⠛⡛⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠉⣠⠶⢛⣋⣿⠿⠷⠒⠾⣿⣦⡈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⣨⣴⠿⢛⣛⣭⡧⢚⣛⢿⣦⡙⢿⣷⡈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⣠⣾⢛⣥⣾⠟⣩⣤⣄⣘⡛⢷⣌⠻⣮⢻⣷⡀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⡄⠀⣴⠟⣡⣾⡟⣱⣿⢩⡿⣿⡿⢻⢊⢻⣧⡙⡜⣿⡄⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⡔⢀⣼⠏⣰⣿⠌⢰⣿⠋⣾⣿⠇⠸⣦⢧⡀⢻⣷⣴⡘⣿⡄⠹⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡷⠁⣾⡏⣰⣿⠟⠀⠠⡅⠠⠥⠀⢠⣧⠙⠈⢷⠀⢻⡿⢡⠘⣧⠀⢿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⢰⡿⢀⣿⡇⠀⠀⠀⠀⢀⠉⢀⣾⣿⣷⡀⠈⠀⠈⣋⠈⠂⠸⠀⡸⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⣿⠇⠸⡏⠀⡀⠁⠒⠀⣀⣴⡟⠯⢭⣿⣿⠆⠀⡼⣽⡇⠀⠀⠀⣱⠘⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠛⠀⠀⠀⢰⣿⣥⣶⣸⣿⣿⣦⡆⢀⢈⣙⢀⣦⡇⡟⠁⠀⠀⠀⠏⣰⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⠿⠀⠀⠰⠀⠘⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣷⠟⣡⣿⠏⠉⠀⠀⢘⣠⣠⣾⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣦⠠⡄⠀⠆⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⡀⠀⠁⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠛⠀⠀⠀⠀⢠⣦⡙⢿⣿⣿⣿⠿⢛⡡⡰⢠⡃⢀⠀⠸⢶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⢿⣿⣿⣿⢿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠙⢃⠀⣬⠉⣠⣴⠟⠠⠶⠿⠛⠀⠀⠀⠀⠉⠛⠿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣏⣭⣶⠊⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⣶⡜⢛⣵⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿
⣿⡿⠷⢨⣿⠏⠁⢀⡀⠀⠀⠀⠀⠀⠀⣀⣀⣀⠀⠀⠀⠈⠁⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿
⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠄⠉⠀⢀⠀⠀⡒⠒⠻⠹⣫⣓⡲⣶⡤⣤⣀⠀⠀⠀⠀⠀⢰⢿⣧⣀⢴⣦⡀⠀⢸⣿⣿
⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠈⠘⠃⠁⠀⢄⣀⣀⡒⠒⠁⠂⠀⣼⣿⢟⣠⡟⠀⠀⠀⣿⣿
⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠜⣡⣴⣯⣽⡒⠦⣤⣤⣀⠀⠀⠀⠀⠈⠉⠉⠙⠉⠁⠀⠀⠀⠉⠃⠾⠿⠃⠀⠀⠀⠸⣿
⣿⡀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⣿⣿⣦⡈⠉⠛⠛⠛⣛⣓⣶⣶⡒⠢⢤⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿
⣿⡇⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣾⣿⣿⣿⣿⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿
⣿⣿⠀⠀⠀⠀⠀⠀⢸⣿⣀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿
⣿⣿⣷⠀⠀⠀⠀⠀⠘⣿⡿⣿⣿⣿⣿⣿⣿⡿⣿⣿⢸⣿⣿⣿⣿⡇⠀⢸⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻
⣿⣿⣿⣧⡀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠟⣱⣿⣿⡌⣿⣿⣿⣿⣷⣾⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸
⣿⣿⣿⣿⣿⣦⣄⣀⣀⣠⢵⣤⣉⣉⣩⣴⣾⣿⣿⣿⣷⡈⠻⣿⣿⣿⣿⣾⡿⠛⣰⡇⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⣉⣉⣉⣁⣶⣾⡿⢡⣾⣄⠀⠀⠀⠀⠀⠀⠀⠀⣰
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⢸⣿⣿⣦⡀⠀⠀⠀⠀⠀⣴⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢃⣾⣿⣿⣿⣿⣦⣤⣤⣴⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡿⢋⢀⡎⣰⣜⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⡀⢈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⡿⢁⢀⣿⢸⠟⣨⡻⣶⣍⣙⣛⠿⠿⠿⠿⠿⠿⠿⢛⣉⣄⣴⡄⣿⣎⢆⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⡿⢡⠁⣸⠇⣾⣼⣿⣿⣶⡭⣙⣻⠿⠿⠿⣿⣿⠿⠿⠟⣋⣅⢿⣷⢸⣿⡄⢄⠻⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀        
             
`));


console.log(chalk.bold.blue(`
Vyros Is Here 🎭
`));

console.log(chalk.blue(`
Bot Connect ✅
`));*/

let sock;

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        sock = makeWASocket ({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
ⓘ Статус кода сопряжения здесь

▢ Your number : ${botNumber}...
▢ Status : Proses...\`\`\`
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket ({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
ⓘ Статус кода сопряжения здесь

▢ Your number : ${botNumber}...
▢ Status : Proses...\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
ⓘ Статус кода сопряжения здесь

▢ Your number : ${botNumber}...
▢ Status : Gagal...\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
ⓘ Статус кода сопряжения здесь

▢ Your number : ${botNumber}...
▢ Status : Suscces...\`\`\`
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
       let customCode = "VYRSKEEL"
       const code = await sock.requestPairingCode(botNumber, customCode);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
ⓘ Статус кода сопряжения здесь

▢ Your number : ${botNumber}...
▢ Code Pairing : ${formattedCode}\`\`\``,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
ⓘ Статус кода сопряжения здесь

▢ Your number : ${botNumber}...
▢ Status : Gagal...\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}






// -------( Fungsional Function Before Parameters )--------- 
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~Get Speed Bots🔧🗑️
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); 
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}


function getRandomImage() {
  const images = [
       "https://files.catbox.moe/d55zab.jpg",
       "https://files.catbox.moe/fpldya.jpg",
       "https://files.catbox.moe/vo17i4.jpg"
  ];
  return images[Math.floor(Math.random() * images.length)];
}

// ~ Coldowwn

let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
    fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
    if (cooldownData.users[userId]) {
        const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
        if (remainingTime > 0) {
            return Math.ceil(remainingTime / 1000); 
        }
    }
    cooldownData.users[userId] = Date.now();
    saveCooldown();
    setTimeout(() => {
        delete cooldownData.users[userId];
        saveCooldown();
    }, cooldownData.time);
    return 0;
}

function setCooldown(timeString) {
    const match = timeString.match(/(\d+)([smh])/);
    if (!match) return "Format salah! Gunakan contoh: /setjeda 5m";

    let [_, value, unit] = match;
    value = parseInt(value);

    if (unit === "s") cooldownData.time = value * 1000;
    else if (unit === "m") cooldownData.time = value * 60 * 1000;
    else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

    saveCooldown();
    return `Cooldown diatur ke ${value}${unit}`;
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(user => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `Ya - ${new Date(user.expiresAt).toLocaleString("id-ID")}`;
  } else {
    return "Tidak - Tidak ada waktu aktif";
  }
}
 
// ---------( The Bug Function)----------



 
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


const bugRequests = {};
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();
  const randomImage = getRandomImage();

  bot.sendPhoto(chatId, randomImage, {
caption: `\`\`\`
( 🍁 ) olá  ${username}\`\`\`
\`\`\`
Здравствуйте, меня зовут  𝗩𝘆𝗿𝗼𝘀 𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁 , и это имя было создано @keelextyy, чтобы вам было легче совершать преступления против людей, которых вы ненавидите.
𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗧 𝗜 𝗢 𝗡
—▢ Developer : @keelextyy
—▢ Bot Name : 𝗩𝘆𝗿𝗼𝘀 𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁 ✰
—▢ Version : 5.0
—▢ Runtime : ${runtime}\`\`\`

*© Vyros — Keel 🍁*
`,

    parse_mode: "Markdown",
    reply_markup: {
     inline_keyboard: [
   [{ text: "𝐀𝐥𝐥°𝐌𝐞𝐧𝐮", callback_data: "infomenu" }],
 [{ text: "𝐒𝐞𝐭𝐭𝐢𝐧𝐠°𝐌𝐞𝐧𝐮", callback_data: "setting" }, { text: "𝐁𝐮𝐠°𝐌𝐞𝐧𝐮", callback_data: "trashmenu" }], 
[{ text: "🌸", url: "https://t.me/aboutvyros" }],
     ] 
    }
  });
});


bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const senderId = query.from.id;
    const runtime = getBotRuntime();
    const premiumStatus = getPremiumStatus(query.from.id);
    const randomImage = getRandomImage();

    let caption = "";
    let replyMarkup = {};

    if (query.data === "trashmenu") {
      caption = `\`\`\`⊝─𝐕𝐲𝐫𝐨𝐬°𝐁𝐮𝐠𝐌𝐞𝐧𝐮\`\`\`
\`\`\`
┏─⊱
—▢ /delaymsg 62xxx
– Crash Delay
– Hard Fix
─────────⊱
—▢ /catalyst
– Crash Delay Invisible 
– Delay Marker 
─────────⊱
—▢ /combo
– Crash Delay Invisible 
– Delay Marker
─────────⊱
—▢ /invisiblemsg
– Invisible Delay
┗─⊱

© Vyross — Keel 🍁\`\`\`
*▢ sᴀʟᴜʀᴀɴ ᴅᴇᴠᴇʟᴏᴘᴇʀ* 
https://whatsapp.com/channel/0029Vaz9GtAICVfdMuMsb724`;
      replyMarkup = { inline_keyboard: [[{ text: "𝐁𝐚𝐜𝐤°𝐌𝐞𝐧𝐮", callback_data: "back_to_main" }]] };
    }
    
    if (query.data === "setting") {
      caption = `\`\`\`⊝─𝐕𝐲𝐫𝐨𝐬°𝐒𝐞𝐭𝐭𝐢𝐧𝐠𝐌𝐞𝐧𝐮\`\`\`
\`\`\`
┏─⊱
—▢ /addsender 628
– connected to WhatsApp
─────────⊱
—▢ /setjeda <durasi>
– s ( second )
– m ( menit ) 
─────────⊱
—▢ /addadmin <id>
– input your id    
─────────⊱
—▢ /listadmin
– see admin list 
─────────⊱ 
—▢ /addprem <id>
– input your id
─────────⊱
—▢ /delprem <id>
– input your id   
─────────⊱
—▢ /listprem
– see premium list  
┗─⊱ \`\`\`

*© Vyross — Keel 🍁*
`;
      replyMarkup = { inline_keyboard: [[{ text: "𝐁𝐚𝐜𝐤°𝐌𝐞𝐧𝐮", callback_data: "back_to_main" }]] };
    }

    if (query.data === "infomenu") {
      caption = `\`\`\`
( 🍁 ) olá,  ${username}\`\`\`
\`\`\`
Здравствуйте, меня зовут  𝗩𝘆𝗿𝗼𝘀 𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁 , и это имя было создано @keelextyy, чтобы вам было легче совершать преступления против людей, которых вы ненавидите.

 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗧 𝗜 𝗢 𝗡
—▢ Developer : @keelextyy
—▢ Bot Name : 𝗩𝘆𝗿𝗼𝘀 𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁 ✰
—▢ Version : 5.0
—▢ Runtime : ${runtime}\`\`\`
\`\`\`⊝─𝐕𝐲𝐫𝐨𝐬°𝐁𝐮𝐠𝐌𝐞𝐧𝐮 
— /delaymsg 628xx
— /catalyst 628xx
— /combo 628xx
— /invisblemsg 628xx\`\`\`
\`\`\`⊝─𝐕𝐲𝐫𝐨𝐬°𝐒𝐞𝐭𝐭𝐢𝐧𝐠𝐌𝐞𝐧𝐮 
— /addsender 628
— /setjeda <durasi>
— /addadmin <id>
— /listadmin
— /addprem <id> <day>
— /delprem <id>
— /listprem\`\`\`
\`\`\`⊝─𝐓𝐡𝐚𝐧𝐤𝐬°𝐓𝐨
—▢ Keelextyy ( dev )
—▢ Ichaaa ( my girlfriend )
– Caywzz ( best friend  )
- RenXiter ( Design )
– WaysModzz ( Dev Xyited )
– Shaasleep ( owner script )
– Dikzz ( owner script )
– My Partner 
– All script ( display inspiration )
– All buyer & pengguna script\`\`\`

*© Vyross — Keel 🍁*
`;
      replyMarkup = { inline_keyboard: [[{ text: "𝐁𝐚𝐜𝐤°𝐌𝐞𝐧𝐮", callback_data: "back_to_main" }]] };
    }

    if (query.data === "back_to_main") {
      caption = `\`\`\`
( 🍁 ) olá  ${username}\`\`\`
\`\`\`
Здравствуйте, меня зовут  𝗩𝘆𝗿𝗼𝘀 𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁 , и это имя было создано @keelextyy, чтобы вам было легче совершать преступления против людей, которых вы ненавидите.
𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗧 𝗜 𝗢 𝗡
—▢ Developer : @keelextyy
—▢ Bot Name : 𝗩𝘆𝗿𝗼𝘀 𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁 ✰
—▢ Version : 5.0
—▢ Runtime : ${runtime}\`\`\`

*© Vyros — Keel 🍁*
`;
      replyMarkup = {
        inline_keyboard: [
 [{ text: "𝐀𝐥𝐥°𝐌𝐞𝐧𝐮", callback_data: "infomenu" }],
 [{ text: "𝐒𝐞𝐭𝐭𝐢𝐧𝐠°𝐌𝐞𝐧𝐮", callback_data: "setting" }, { text: "𝐁𝐮𝐠°𝐌𝐞𝐧𝐮", callback_data: "trashmenu" }], 
[{ text: "🌸", url: "https://t.me/aboutvyros" }],
      ]
      };
    }

    await bot.editMessageMedia(
      {
        type: "photo",
        media: randomImage,
        caption: caption,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});

bot.onText(/\/broadcast (.+)/, (msg, match) => {

    const chatId = msg.chat.id;

    const messageToBroadcast = match[1];

    // **PENTING: Tambahkan logika otorisasi admin di sini!**

    const adminUserId = 7647760693; // Ganti dengan ID Telegram admin Anda

    if (chatId === adminUserId) {

        const allUserIds = readUserIds();

        let sentCount = 0;

        let failedCount = 0;

        allUserIds.forEach(userId => {

            bot.sendMessage(userId, messageToBroadcast)

                .then(() => {

                    sentCount++;

                })

                .catch((error) => {

                    console.error(`Gagal mengirim pesan ke ${userId}:`, error.message);

                    failedCount++;

                });

        });

        bot.sendMessage(chatId, `Pesan broadcast dikirim ke ${sentCount} pengguna. Gagal dikirim ke ${failedCount} pengguna.`);

    } else {

        bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menggunakan perintah ini.');

    }

});

// **Integrasikan logika bot Anda yang lain

//Case The Bug

bot.onText(/\/invisiblemsg (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `\`\`\`アクセスできません!\`\`\`
( ! ) Tidak ada akses silahkan beli akses atau juga bisa membeli script ke owner, contact owner ada di tombol di bawahh`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/keelextyy" }]
        ]
      }
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender 62xxx");
    }

    const sentMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/mq5ccz.jpg", {
      caption: `
\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
–▢ Target : ${formattedNumber}
–▢ Command : Invisiblemsg
–▢ status : Sending Process..
\`\`\`
`, parse_mode: "Markdown"
    });
    await sleep(5000);
await bot.editMessageCaption(`
\`\`\`⊝──𝗩𝘆𝗿𝗼𝘀–𝗖𝗮𝘁𝗮𝗹𝘆𝘀𝘁✰
–▢ Target : ${formattedNumber}
–▢ Command : Invisiblemsg
–▢ status : Success Sending🦠\`\`\`
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "🌸", url: `https://t.me/aboutvyros` }]]
      }
    });
    
    console.log("\x1b[32m[PROCES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await delayoverload(jid)
    await console.log("\x1b[32m[SUKSES]\x1b[0m Bug berhasil dikirim! 🚀");
    
    
    
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

//End The Csse Bug

//=====================================
bot.onText(/\/addsender (.+)/, async (msg, match) => {
const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Missing input. Please provide the number. Example: /addsender 62xxxx.");
  }
  
  const botNumber = match[1].replace(/[^0-9]/g, "");

  if (!botNumber || botNumber.length < 10) {
    return bot.sendMessage(chatId, "❌ Nomor yang diberikan tidak valid. Pastikan nomor yang dimasukkan benar.");
  }

  try {
    await connectToWhatsApp(botNumber, chatId);
    bot.sendMessage(chatId, "✅ Nomor berhasil ditambahkan sebagai pengirim.");
  } catch (error) {
    console.error("Error in addsender:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});



const moment = require('moment');

bot.onText(/\/setjeda (\d+[smh])/, (msg, match) => { 
const chatId = msg.chat.id; 
const response = setCooldown(match[1]);

bot.sendMessage(chatId, response); });


bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ You are not authorized to add premium users.");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID and duration. Example: /addprem ID 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Missing input. Please specify a duration. Example: /addprem ID 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number. Example: /addprem ID 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ Invalid duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} added ${userId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ User ${userId} has been added to the premium list until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ You are not authorized to view the premium list.");
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 No premium users found.");
  }

  let message = "```LIST - VIP🎭 \n\n```";
  premiumUsers.forEach((user, keelvyros) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${keelvyros + 1}. ID: \`${user.id}\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
//=====================================
bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addadmin id.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addadmin id.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${userId} To Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
    }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Please provide a user ID. Example: /delprem id");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
    }

    // Cari keelvyros user dalam daftar premium
    const keelvyros = premiumUsers.findkeelvyros(user => user.id === userId);
    if (keelvyros === -1) {
        return bot.sendMessage(chatId, `❌ User ${userId} is not in the premium list.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(keelvyros, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ User ${userId} has been removed from the premium list.`);
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
    if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
            { parse_mode: "Markdown" }
        );
    }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /deladmin id.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /deladmin id.");
    }

    // Cari dan hapus user dari adminUsers
    const adminkeelvyros = adminUsers.keelvyrosOf(userId);
    if (adminkeelvyros !== -1) {
        adminUsers.splice(adminkeelvyros, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been removed from admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
    }
});